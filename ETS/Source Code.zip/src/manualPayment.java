public class manualPayment extends paymentService{

    public manualPayment(String paymentMethod, String paymentStatus) {
        super(paymentMethod, paymentStatus);

    }
    
}
