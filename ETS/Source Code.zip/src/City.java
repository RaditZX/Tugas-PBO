public class City {
    private String origin;
    private String destination;


    public City(String origin, String destination) {
        this.origin = origin;
        this.destination = destination;
    }


    public String getOrigin() {
        return origin;
    }


    public String getDestination() {
        return destination;
    }




    

    
    
}
