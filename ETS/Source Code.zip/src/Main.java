import java.io.File;
import java.io.FileReader;
import com.google.gson.*;

public class Main {
    public static void main(String[] args) throws Exception {

       digitalPayment qris = new digitalPayment("qris", "Settlement");
       manualPayment cash = new manualPayment("cash", "Succes");

       Gson gson =  new Gson();

       File initialFile = new File("src/jsonfile.json");
       Delivery[] delivery = gson.fromJson(new FileReader(initialFile ), Delivery[].class);
       
       System.out.printf(" | %-20s | %-17s | %-17s | %-17s | %-17s | %-17s  | %-17s | %-17s | %-17s \n ", 
       "productName",
       "quantity",
       "weight",
       "destination",
       "servicePackage",
       "serviceValue",
       "Total",
       "PaymentMethod",
       "PaymentStatus" );
       for (int i = 0 ; i < delivery.length;  i ++){
            System.out.printf("| %-20s | %-17s | %-17s | %-17s | %-17s | %-17s  | %-17s | %-17s | %-17s\n ", 
            delivery[i].getProductName() , 
            delivery[i].getQuantity(),
            delivery[i].getWeight(),
            delivery[i].getCity().getDestination(),
            delivery[i].getServicePackage().getService(),
            delivery[i].getServicePackage().getValue(),
            delivery[i].getServicePackage().getValue(),
            i == 0 ? delivery[i].getPaymentServiceName(qris) : delivery[i].getPaymentServiceName(cash),
            i == 0 ?delivery[i].getPaymentServiceStatus(qris) : delivery[i].getPaymentServiceStatus(cash));
       }
    }
}
