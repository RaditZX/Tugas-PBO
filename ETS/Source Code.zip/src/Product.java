class Product{
    private String productName;
    private int priceItem;
    private int weight;
    private int city;
    
    public Product(String productName, int priceItem, int weight, int city) {
        this.productName = productName;
        this.priceItem = priceItem;
        this.weight = weight;
        this.city = city;
    }
    public String getProductName() {
        return productName;
    }
    public int getPriceItem() {
        return priceItem;
    }
    public int getWeight() {
        return weight;
    }
    public int getCity() {
        return city;
    }

    

    
}