abstract class paymentService {
    private String paymentMethod;
    private String paymentStatus;

    public paymentService(String paymentMethod, String paymentStatus) {
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }


    


}
