public class Delivery {
    Status status;
    ServicePackage servicePackage;
    City city;
    private String productName;
    private int priceItem;
    private int weight;
    private int quantity;

    
    public Delivery(Status status, ServicePackage servicePackage, City city) {
        this.status = status;
        this.servicePackage = servicePackage;
        this.city = city;
    }

    public Status getStatus() {
        return status;
    }

    public ServicePackage getServicePackage() {
        return servicePackage;
    }


    public City getCity() {
        return city;
    }


    public String getProductName() {
        return productName;
    }

    public int getPriceItem() {
        return priceItem;
    }

    public int getWeight() {
        return weight;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getPaymentServiceName(paymentService p){
        return p.getPaymentMethod();
    }

    public String getPaymentServiceStatus(paymentService p){
        return p.getPaymentStatus();
    }

    

    

    

    
    
}
