/**
 * digitalPayment
 */
public class digitalPayment extends paymentService {

    public digitalPayment(String paymentMethod, String paymentStatus) {
        super(paymentMethod, paymentStatus);
    }

}