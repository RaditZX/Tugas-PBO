class A {
    public void displayClass() {
        System.out.println("Inside super class A");
    }
}