class C extends A {
    public void displayClass() {
        System.out.println("Inside sub class C");
    }
}