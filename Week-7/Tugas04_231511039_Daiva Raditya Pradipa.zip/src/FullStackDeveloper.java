/**
 * FullStackDeveloper
 */
public class FullStackDeveloper extends SoftwareDeveloper implements FrontendSkills, BackEndSkills {

    public FullStackDeveloper(String nama, String company) {
        super(nama, company);
    }

    @Override
    public void BuatCRUD() {
        System.out.println("Buat Operasi CRUD untuk setiap screen");
    }

    @Override
    public void MigrateDatabase() {
        System.out.println("Migrasti schema database yang telah dibuat database engineer");
    }
    
    @Override
    public void implementasiUIUX(){
        System.out.println("Implementasi UI/UX untuk perangkat mobile dan platform web");
    }

    @Override
    public void ConsumeAPI() {
        System.out.println("Consuming API form Backend Server");
    }

    
}