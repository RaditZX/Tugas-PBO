public class WebFrontEndDeveloper extends FrontEndDeveloper {

    public WebFrontEndDeveloper(String nama, String company){
        super(nama,company);
    }

    @Override
    public void implementasiUIUX(){
        System.out.println("Implementasi UI/UX untuk platform web");
    }

}
