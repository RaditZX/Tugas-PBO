public class Main {
    public static void main(String[] args) throws Exception {
        
        MobileFrontEndDeveloper mb = new MobileFrontEndDeveloper("Yahya", "PT.GITS INDONESIA");
        System.out.println("Nama : " + mb.getName());
        System.out.println("Company : " + mb.getCompany());
        mb.implementasiUIUX();
        mb.ConsumeAPI();
        mb.attendMeet();
        System.out.print("\n");

        WebFrontEndDeveloper wd = new WebFrontEndDeveloper("Daiva", "Google Company");
        System.out.println("Nama : " + wd.getName());
        System.out.println("Company : " + wd.getCompany());
        wd.implementasiUIUX();
        wd.ConsumeAPI();
        wd.attendMeet();
        System.out.print("\n");

        BackEndDeveloper bd = new BackEndDeveloper("Tresh", "Amazon");
        System.out.println("Nama : " + bd.getName());
        System.out.println("Company : " + bd.getCompany());
        bd.MigrateDatabase();
        bd.BuatCRUD();
        bd.attendMeet();
        System.out.print("\n");

        FullStackDeveloper fs = new FullStackDeveloper("Daffa", "PT CARISSA");
        System.out.println("Nama : " + fs.getName());
        System.out.println("Company : " + fs.getCompany());
        fs.implementasiUIUX();
        fs.MigrateDatabase();
        fs.BuatCRUD();
        fs.ConsumeAPI();
        fs.attendMeet();
        System.out.print("\n"); 
    }
}
