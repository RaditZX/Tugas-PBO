public class BackEndDeveloper extends SoftwareDeveloper implements BackEndSkills  {
    
    public BackEndDeveloper(String name, String company){
        super(name, company);
    }

    @Override
    public void BuatCRUD() {
        System.out.println("Buat Operasi CRUD untuk setiap screen");
    }

    @Override
    public void MigrateDatabase() {
        System.out.println("Migrasti schema database yang telah dibuat database engineer");
    }
   
}
