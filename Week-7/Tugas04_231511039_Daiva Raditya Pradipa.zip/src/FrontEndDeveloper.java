abstract class FrontEndDeveloper extends SoftwareDeveloper implements FrontendSkills{

    public FrontEndDeveloper(String nama, String company){
        super(nama,company);
    }

    public abstract void implementasiUIUX();

    @Override
    public void ConsumeAPI(){
        System.out.println("Consuming API form Backend Server");
    }

}
