/**
 * BackEndSkills
 */
public interface BackEndSkills {

    abstract void BuatCRUD();
    abstract void MigrateDatabase();
}