/**
 * FrontendSkills
 */
public interface FrontendSkills {
    abstract void implementasiUIUX();
    abstract void ConsumeAPI();
} 