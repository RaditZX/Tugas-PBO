abstract class SoftwareDeveloper{
    private String name;
    private String company;

    public SoftwareDeveloper(String nama, String company){
        this.name = nama;
        this.company = company;
    }

    public String getName(){
        return this.name;
    }

    public String getCompany(){
        return this.company;
    }

    public void attendMeet(){
        System.out.println("attend proyek progress meet");
    }
}